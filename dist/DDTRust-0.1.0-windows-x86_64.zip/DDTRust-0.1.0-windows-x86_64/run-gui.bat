@echo off
start "" "%~dp0ddtrust-gui.exe" %*
